public class ConditionalsCorrections {

    public static void main(String[] args) {

        // 1. Puede votar
        int userAge = 20;

        if (userAge >= 18) {
            System.out.println("El usuario puede votar");
        } else {
            System.out.println("El usuario NO puede votar");
        }

        // 2. Número mayor
        int firstNumber = 25;
        int secondNumber = 18;

        if (firstNumber > secondNumber) {
            System.out.println("El primer número es mayor");
        } else if (firstNumber < secondNumber) {
            System.out.println("El segundo número es mayor");
        } else {
            System.out.println("Ambos números son iguales");
        }

        // 3. Positivo, negativo o cero
        int number = -5;

        if (number > 0) {
            System.out.println("Positivo");
        } else if (number < 0) {
            System.out.println("Negativo");
        } else {
            System.out.println("Cero");
        }

        // 4. Par o impar
        int numberToCheck = 7;

        if (numberToCheck % 2 == 0) {
            System.out.println("Par");
        } else {
            System.out.println("Impar");
        }

        // 5. Rango 1-100
        int rangeNumber = 75;

        if (rangeNumber >= 1 && rangeNumber <= 100) {
            System.out.println("Está en rango");
        } else {
            System.out.println("Fuera de rango");
        }

        // 6. Día de semana
        int dayOfWeek = 3;

        switch (dayOfWeek) {
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miércoles");
                break;
            default:
                System.out.println("Otro día");
        }

        // 7. Notas
        int grade = 85;

        if (grade >= 90) {
            System.out.println("Sobresaliente");
        } else if (grade >= 70) {
            System.out.println("Aprobado");
        } else {
            System.out.println("Suspenso");
        }

        // 8. Cine
        int cinemaAge = 12;
        boolean accompanied = true;

        if (cinemaAge >= 15 || accompanied) {
            System.out.println("Puede entrar al cine");
        } else {
            System.out.println("No puede entrar");
        }

        // 9. Vocal o consonante
        char letter = 'a';

        if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
            System.out.println("Es vocal");
        } else {
            System.out.println("Es consonante");
        }

        // 10. Mayor de tres
        int a = 25;
        int b = 42;
        int c = 18;

        if (a >= b && a >= c) {
            System.out.println("a es mayor");
        } else if (b >= a && b >= c) {
            System.out.println("b es mayor");
        } else {
            System.out.println("c es mayor");
        }
    }
}
