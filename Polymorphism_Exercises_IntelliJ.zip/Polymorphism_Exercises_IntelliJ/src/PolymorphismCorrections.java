import java.util.ArrayList;

public class PolymorphismCorrections {

    public static void main(String[] args) {

        // 1. Polimorfismo con sonidos de animales.
        ArrayList<Animal> animalList = new ArrayList<>();
        animalList.add(new Dog());
        animalList.add(new Cat());
        animalList.add(new Cow());

        for (Animal animal : animalList) {
            animal.makeSound();
        }

        // 2. Polimorfismo con áreas de figuras.
        ArrayList<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(5.0));
        shapes.add(new Rectangle(4.0, 6.0));
        shapes.add(new Circle(3.0));

        for (Shape shape : shapes) {
            System.out.println("Área: " + shape.calculateArea());
        }

        // 3. Sobrecarga de métodos en Printer.
        Printer printer = new Printer();
        printer.print("Hola, Java!");
        printer.print(42);
        printer.print(3.14);

        // 4. Sobrecarga de métodos en Greeter.
        Greeter greeter = new Greeter();
        greeter.greet();
        greeter.greet("Brais");

        // 5. Polimorfismo con vehículos.
        ArrayList<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Car());
        vehicles.add(new Bike());
        vehicles.add(new Truck());

        for (Vehicle vehicle : vehicles) {
            vehicle.start();
        }

        // 6. Polimorfismo con notificaciones.
        sendNotification(new EmailNotification());
        sendNotification(new SMSNotification());

        // 7. Tipos de animales mediante sobrescritura.
        showAnimalType(new DogType());
        showAnimalType(new CatType());
        showAnimalType(new HorseType());

        // 8. Sobrecarga de métodos en Converter.
        Converter converter = new Converter();
        System.out.println(converter.convert(100));
        System.out.println(converter.convert(25.75));
        System.out.println(converter.convert("Java"));

        // 9. Productos con lógica de descuento sobrescrita.
        ArrayList<Product> products = new ArrayList<>();
        products.add(new Book(25.0));
        products.add(new Electronic(150.0));
        products.add(new Book(30.0));

        for (Product product : products) {
            System.out.println("Precio final: €" + product.getPrice());
        }

        // 10. Personajes con distintos ataques.
        System.out.println("\n=== Ejercicio 10: Character con array ===");
        Character[] characters = { new Warrior(), new Archer(), new Mage() };

        for (Character character : characters) {
            character.attack();
        }
    }

    // 1. Clases Animal, Dog, Cat y Cow
    public static class Animal {
        public void makeSound() {
            System.out.println("El animal hace un sonido");
        }
    }

    public static class Dog extends Animal {
        @Override
        public void makeSound() {
            System.out.println("El perro hace: Guau");
        }
    }

    public static class Cat extends Animal {
        @Override
        public void makeSound() {
            System.out.println("El gato hace: Miau");
        }
    }

    public static class Cow extends Animal {
        @Override
        public void makeSound() {
            System.out.println("La vaca hace: Muu");
        }
    }

    // 2. Clases Shape, Circle y Rectangle
    public static abstract class Shape {
        public abstract double calculateArea();
    }

    public static class Circle extends Shape {
        private final double radius;

        public Circle(double radius) {
            this.radius = radius;
        }

        @Override
        public double calculateArea() {
            return Math.PI * radius * radius;
        }
    }

    public static class Rectangle extends Shape {
        private final double width;
        private final double height;

        public Rectangle(double width, double height) {
            this.width = width;
            this.height = height;
        }

        @Override
        public double calculateArea() {
            return width * height;
        }
    }

    // 3. Clase Printer
    public static class Printer {
        public void print(String text) {
            System.out.println("Imprimiendo texto: " + text);
        }

        public void print(int number) {
            System.out.println("Imprimiendo número entero: " + number);
        }

        public void print(double number) {
            System.out.println("Imprimiendo número decimal: " + number);
        }
    }

    // 4. Clase Greeter
    public static class Greeter {
        public void greet() {
            System.out.println("Hello");
        }

        public void greet(String name) {
            System.out.println("Hello, " + name);
        }
    }

    // 5. Clases Vehicle, Car, Bike y Truck
    public static class Vehicle {
        public void start() {
            System.out.println("El vehículo está arrancando");
        }
    }

    public static class Car extends Vehicle {
        @Override
        public void start() {
            System.out.println("El coche está arrancando con el motor");
        }
    }

    public static class Bike extends Vehicle {
        @Override
        public void start() {
            System.out.println("La bicicleta está lista para pedalear");
        }
    }

    public static class Truck extends Vehicle {
        @Override
        public void start() {
            System.out.println("El camión está arrancando con motor diésel");
        }
    }

    // 6. Clases Notification, EmailNotification y SMSNotification
    public static class Notification {
        public void send() {
            System.out.println("Enviando notificación");
        }
    }

    public static class EmailNotification extends Notification {
        @Override
        public void send() {
            System.out.println("Enviando notificación por email");
        }
    }

    public static class SMSNotification extends Notification {
        @Override
        public void send() {
            System.out.println("Enviando notificación por SMS");
        }
    }

    public static void sendNotification(Notification notification) {
        notification.send();
    }

    // 7. Clases AnimalType, DogType, CatType y HorseType
    public static abstract class AnimalType {
        public abstract String getType();
    }

    public static class DogType extends AnimalType {
        @Override
        public String getType() {
            return "Perro";
        }
    }

    public static class CatType extends AnimalType {
        @Override
        public String getType() {
            return "Gato";
        }
    }

    public static class HorseType extends AnimalType {
        @Override
        public String getType() {
            return "Caballo";
        }
    }

    public static void showAnimalType(AnimalType animal) {
        System.out.println("Tipo de animal: " + animal.getType());
    }

    // 8. Clase Converter
    public static class Converter {
        public String convert(int number) {
            return "Número entero convertido: " + number + " -> '" + number + "'";
        }

        public String convert(double number) {
            return "Número decimal convertido: " + number + " -> '" + String.format("%.2f", number) + "'";
        }

        public String convert(String text) {
            return "Texto convertido: " + text + " -> '" + text.toUpperCase() + "'";
        }
    }

    // 9. Clases Product, Book y Electronic
    public static class Product {
        protected double basePrice;

        public Product(double basePrice) {
            this.basePrice = basePrice;
        }

        public double getPrice() {
            return basePrice;
        }
    }

    public static class Book extends Product {
        public Book(double basePrice) {
            super(basePrice);
        }

        @Override
        public double getPrice() {
            return basePrice * 0.9;
        }
    }

    public static class Electronic extends Product {
        public Electronic(double basePrice) {
            super(basePrice);
        }

        @Override
        public double getPrice() {
            return basePrice * 0.95;
        }
    }

    // 10. Clases Character, Warrior, Archer y Mage
    public static abstract class Character {
        public abstract void attack();
    }

    public static class Warrior extends Character {
        @Override
        public void attack() {
            System.out.println("El guerrero ataca con su espada");
        }
    }

    public static class Archer extends Character {
        @Override
        public void attack() {
            System.out.println("El arquero dispara con su arco");
        }
    }

    public static class Mage extends Character {
        @Override
        public void attack() {
            System.out.println("El mago lanza un hechizo");
        }
    }
}
