# Proyecto Java - Beginner

Este proyecto contiene una carpeta separada con ejercicios básicos de variables y constantes para abrir directamente en IntelliJ IDEA.

## Archivos incluidos

- `BeginnerExercises.java`: enunciados de los ejercicios.
- `BeginnerCorrections.java`: ejercicios resueltos y corregidos.

## Cómo abrirlo en IntelliJ IDEA

1. Abre IntelliJ IDEA.
2. Selecciona `Open`.
3. Elige la carpeta `JavaPOO_IntelliJ_Carpeta_Beginner`.
4. Entra a `src`.
5. Ejecuta `BeginnerCorrections.java` para ver el resultado.
