public class AccessModifiersCorrections {

    public static void main(String[] args) {

        // 1. Clase Person con atributos privados, getters y setters.
        PersonExample person1 = new PersonExample();
        person1.setName("Brais Moure");
        person1.setAge(38);
        System.out.println("Nombre: " + person1.getName());
        System.out.println("Edad: " + person1.getAge());

        // 2. Product con price privado y validación.
        ProductExample product1 = new ProductExample("Teclado");
        product1.setPrice(199.99);
        System.out.println("Precio válido: €" + product1.getPrice());
        product1.setPrice(-50.0);

        // 3. BankAccount con depósitos y retiros validados.
        BankAccountExample account1 = new BankAccountExample("12345");
        account1.deposit(1000.0);
        account1.withdraw(300.0);
        account1.withdraw(800.0);
        account1.deposit(-50.0);

        // 4. Book con título de solo lectura.
        BookExample book1 = new BookExample("Reina Roja");
        System.out.println("Título del libro: " + book1.getTitle());

        // 5. Temperature con rango permitido.
        TemperatureExample temp1 = new TemperatureExample();
        temp1.setCelsius(25.5);
        System.out.println("Temperatura: " + temp1.getCelsius() + "°C");
        temp1.setCelsius(150.0);
        temp1.setCelsius(-150.0);

        // 6. User con comprobación de contraseña.
        UserExample user1 = new UserExample();
        user1.setUsername("mouredev");
        user1.setPassword("miPassword123");
        System.out.println("Usuario: " + user1.getUsername());
        System.out.println("¿Contraseña correcta? " + user1.checkPassword("miPassword123"));
        System.out.println("¿Contraseña incorrecta? " + user1.checkPassword("password123"));

        // 7. Employee con aumento de salario.
        EmployeeExample emp1 = new EmployeeExample("Brais Moure", 2500.0);
        emp1.showInfo();
        emp1.raiseSalary(10.0);
        emp1.showInfo();
        emp1.raiseSalary(-5.0);

        // 8. Rectangle con cálculo de área.
        RectangleExample rect1 = new RectangleExample();
        rect1.setWidth(5.0);
        rect1.setHeight(3.0);
        System.out.println("Dimensiones: " + rect1.getWidth() + " x " + rect1.getHeight());
        System.out.println("Área: " + rect1.calculateArea());

        // 9. Student con nota y comprobación de aprobación.
        StudentExample student1 = new StudentExample("Brais Moure");
        student1.setGrade(85);
        System.out.println("Estudiante: " + student1.getName());
        System.out.println("Nota: " + student1.getGrade());
        System.out.println("¿Ha aprobado? " + student1.isPassed());

        student1.setGrade(45);
        System.out.println("Nueva nota: " + student1.getGrade());
        System.out.println("¿Ha aprobado? " + student1.isPassed());

        // 10. Car con límites de velocidad.
        CarExample car1 = new CarExample("DMC DeLorean");
        car1.showStatus();
        car1.accelerate(50);
        car1.showStatus();
        car1.accelerate(80);
        car1.showStatus();
        car1.brake(30);
        car1.showStatus();
        car1.brake(100);
        car1.showStatus();
    }
}

class PersonExample {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            System.out.println("El nombre no puede estar vacío");
        }
    }

    public void setAge(int age) {
        if (age >= 0 && age <= 120) {
            this.age = age;
        } else {
            System.out.println("La edad debe estar entre 0 y 120 años");
        }
    }
}

class ProductExample {
    private String name;
    private double price;

    public ProductExample(String name) {
        this.name = name;
        this.price = 0.0;
    }

    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
            System.out.println("Precio actualizado a: €" + price);
        } else {
            System.out.println("El precio debe ser mayor a 0");
        }
    }

    public double getPrice() {
        return price;
    }
}

class BankAccountExample {
    private String accountNumber;
    private double balance;

    public BankAccountExample(String accountNumber) {
        this.accountNumber = accountNumber;
        this.balance = 0.0;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Depósito de €" + amount + " realizado. Saldo actual: €" + balance);
        } else {
            System.out.println("El monto del depósito debe ser positivo");
        }
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("El monto del retiro debe ser positivo");
        } else if (amount > balance) {
            System.out.println("Fondos insuficientes. Saldo actual: €" + balance);
        } else {
            balance -= amount;
            System.out.println("Retiro de €" + amount + " realizado. Saldo actual: €" + balance);
        }
    }
}

class BookExample {
    private final String title;

    public BookExample(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}

class TemperatureExample {
    private double celsius;

    public void setCelsius(double celsius) {
        if (celsius >= -100 && celsius <= 100) {
            this.celsius = celsius;
            System.out.println("Temperatura establecida a: " + celsius + "°C");
        } else {
            System.out.println("La temperatura debe estar entre -100°C y 100°C");
        }
    }

    public double getCelsius() {
        return celsius;
    }
}

class UserExample {
    private String username;
    private String password;

    public void setUsername(String username) {
        if (username != null && username.length() >= 3) {
            this.username = username;
            System.out.println("Nombre de usuario establecido");
        } else {
            System.out.println("El nombre de usuario debe tener al menos 3 caracteres");
        }
    }

    public void setPassword(String password) {
        if (password != null && password.length() >= 6) {
            this.password = password;
            System.out.println("Contraseña establecida");
        } else {
            System.out.println("La contraseña debe tener al menos 6 caracteres");
        }
    }

    public boolean checkPassword(String inputPassword) {
        return password != null && password.equals(inputPassword);
    }

    public String getUsername() {
        return username;
    }
}

class EmployeeExample {
    private String name;
    private double salary;

    public EmployeeExample(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double percent) {
        if (percent > 0) {
            double increase = salary * (percent / 100);
            salary += increase;
            System.out.println("Salario aumentado en " + percent + "%. Nuevo salario: €" + salary);
        } else {
            System.out.println("El porcentaje de aumento debe ser positivo");
        }
    }

    public void showInfo() {
        System.out.println("Empleado: " + name + ", Salario: €" + salary);
    }
}

class RectangleExample {
    private double width;
    private double height;

    public void setWidth(double width) {
        if (width > 0) {
            this.width = width;
        } else {
            System.out.println("El ancho debe ser positivo");
        }
    }

    public void setHeight(double height) {
        if (height > 0) {
            this.height = height;
        } else {
            System.out.println("La altura debe ser positiva");
        }
    }

    public double calculateArea() {
        return width * height;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }
}

class StudentExample {
    private String name;
    private int grade;

    public StudentExample(String name) {
        this.name = name;
        this.grade = 0;
    }

    public void setGrade(int grade) {
        if (grade >= 0 && grade <= 100) {
            this.grade = grade;
        } else {
            System.out.println("La nota debe estar entre 0 y 100");
        }
    }

    public boolean isPassed() {
        return grade >= 60;
    }

    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;
    }
}

class CarExample {
    private String model;
    private int speed;
    private static final int MAX_SPEED = 120;

    public CarExample(String model) {
        this.model = model;
        this.speed = 0;
    }

    public void accelerate(int amount) {
        if (amount > 0) {
            int newSpeed = speed + amount;
            if (newSpeed <= MAX_SPEED) {
                speed = newSpeed;
                System.out.println("Acelerando +" + amount + " km/h");
            } else {
                speed = MAX_SPEED;
                System.out.println("Velocidad limitada al máximo de " + MAX_SPEED + " km/h");
            }
        } else {
            System.out.println("La cantidad a acelerar debe ser positiva");
        }
    }

    public void brake(int amount) {
        if (amount > 0) {
            int newSpeed = speed - amount;
            if (newSpeed >= 0) {
                speed = newSpeed;
                System.out.println("Frenando -" + amount + " km/h");
            } else {
                speed = 0;
                System.out.println("Vehículo detenido");
            }
        } else {
            System.out.println("La cantidad a frenar debe ser positiva");
        }
    }

    public void showStatus() {
        System.out.println("Vehículo: " + model + ", Velocidad actual: " + speed + " km/h");
    }
}
