public class OperatorsCorrections {

    public static void main(String[] args) {

        // 1. Crea una variable con el resultado de cada operación aritmética.
        int a = 15;
        int b = 4;

        int sum = a + b;
        int subtraction = a - b;
        int multiplication = a * b;
        int division = a / b;
        int modulus = a % b;

        System.out.println("=== OPERADORES ARITMÉTICOS ===");
        System.out.println("a = " + a + ", b = " + b);
        System.out.println("Suma: " + a + " + " + b + " = " + sum);
        System.out.println("Resta: " + a + " - " + b + " = " + subtraction);
        System.out.println("Multiplicación: " + a + " * " + b + " = " + multiplication);
        System.out.println("División: " + a + " / " + b + " = " + division);
        System.out.println("Módulo: " + a + " % " + b + " = " + modulus);

        // 2. Operadores de asignación
        System.out.println("\n=== OPERADORES DE ASIGNACIÓN ===");
        int x = 10;
        System.out.println("Valor inicial de x: " + x);

        x += 5;
        System.out.println("x += 5: " + x);

        x -= 3;
        System.out.println("x -= 3: " + x);

        x *= 2;
        System.out.println("x *= 2: " + x);

        x /= 4;
        System.out.println("x /= 4: " + x);

        x %= 3;
        System.out.println("x %= 3: " + x);

        // 3. Comparaciones verdaderas
        System.out.println("\n=== COMPARACIONES VERDADERAS ===");
        System.out.println("10 == 10: " + (10 == 10));
        System.out.println("15 > 8: " + (15 > 8));
        System.out.println("5 <= 5: " + (5 <= 5));

        // 4. Comparaciones falsas
        System.out.println("\n=== COMPARACIONES FALSAS ===");
        System.out.println("7 != 7: " + (7 != 7));
        System.out.println("3 >= 9: " + (3 >= 9));
        System.out.println("20 < 15: " + (20 < 15));

        // 5. AND
        System.out.println("\n=== OPERADOR LÓGICO AND (&&) ===");
        int age = 25;
        boolean hasLicense = true;
        boolean canDrive = age >= 18 && hasLicense;
        System.out.println("¿Puede conducir? " + canDrive);

        // 6. OR
        System.out.println("\n=== OPERADOR LÓGICO OR (||) ===");
        boolean isWeekend = true;
        boolean isVacation = false;
        boolean canRest = isWeekend || isVacation;
        System.out.println("¿Puede descansar? " + canRest);

        // 7. AND + OR
        System.out.println("\n=== COMBINANDO AND Y OR ===");
        int temperature = 25;
        boolean isSunny = true;
        boolean isRaining = false;
        boolean isGoodWeather = (temperature > 20 && isSunny) || !isRaining;
        System.out.println("¿Es buen clima? " + isGoodWeather);

        // 8. Negación
        System.out.println("\n=== NEGACIÓN ===");
        boolean raining = false;
        System.out.println("No llueve: " + !raining);

        // 9. Unarios
        System.out.println("\n=== OPERADORES UNARIOS ===");
        int num = 5;
        System.out.println(+num);
        System.out.println(-num);
        System.out.println(++num);

        // 10. Combinación completa
        System.out.println("\n=== COMBINACIÓN DE OPERADORES ===");
        int price = 100;
        int discount = 15;
        boolean vip = true;

        int finalPrice = price - (price * discount / 100);
        boolean applies = vip && finalPrice > 50;

        System.out.println("Precio final: $" + finalPrice);
        System.out.println("¿Aplica promoción? " + applies);
    }
}
