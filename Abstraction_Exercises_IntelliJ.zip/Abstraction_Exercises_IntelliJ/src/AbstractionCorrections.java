public class AbstractionCorrections {

    public static void main(String[] args) {

        // 1. Clase abstracta Shape y sus implementaciones.
        Shape circle = new Circle(5.0);
        Shape rectangle = new Rectangle(4.0, 6.0);
        System.out.println("Área del círculo: " + circle.calculateArea());
        System.out.println("Área del rectángulo: " + rectangle.calculateArea());

        // 2. Interfaz Playable.
        Playable guitar = new Guitar();
        Playable piano = new Piano();
        guitar.play();
        piano.play();

        // 3. Clase abstracta Animal y polimorfismo.
        Animal[] animals = { new Dog(), new Cat() };
        for (Animal animal : animals) {
            animal.makeSound();
        }

        // 4. Interfaz Drawable.
        Drawable[] drawings = { new DrawableCircle(), new DrawableSquare(), new DrawableTriangle() };
        for (Drawable drawing : drawings) {
            drawing.draw();
        }

        // 5. Clase abstracta Employee.
        Employee fullTime = new FullTimeEmployee(3000.0);
        Employee partTime = new PartTimeEmployee(20, 15.0);
        System.out.println("Salario empleado tiempo completo: $" + fullTime.calculateSalary());
        System.out.println("Salario empleado medio tiempo: $" + partTime.calculateSalary());

        // 6. Interfaz Movable.
        Movable car = new Car();
        Movable robot = new Robot();
        car.move();
        robot.move();

        // 7. Clase abstracta Appliance.
        Appliance tv = new TV();
        Appliance washingMachine = new WashingMachine();
        tv.turnOn();
        tv.turnOff();
        washingMachine.turnOn();
        washingMachine.turnOff();

        // 8. Dos interfaces implementadas por Duck.
        Duck duck = new Duck();
        duck.fly();
        duck.swim();

        // 9. Clase abstracta Document.
        Document pdf = new PDFDocument();
        Document word = new WordDocument();
        pdf.print();
        word.print();

        // 10. Interfaz Payable.
        Payable invoice = new Invoice(500.0);
        Payable employeePayment = new EmployeePayment("Brais", 2500.0);
        invoice.pay();
        employeePayment.pay();
    }

    // 1. Clases Shape, Circle y Rectangle
    public static abstract class Shape {
        public abstract double calculateArea();
    }

    public static class Circle extends Shape {
        private final double radius;

        public Circle(double radius) {
            this.radius = radius;
        }

        @Override
        public double calculateArea() {
            return Math.PI * radius * radius;
        }
    }

    public static class Rectangle extends Shape {
        private final double width;
        private final double height;

        public Rectangle(double width, double height) {
            this.width = width;
            this.height = height;
        }

        @Override
        public double calculateArea() {
            return width * height;
        }
    }

    // 2. Interfaz Playable y clases Guitar y Piano
    public interface Playable {
        void play();
    }

    public static class Guitar implements Playable {
        @Override
        public void play() {
            System.out.println("Tocando la guitarra: ♪ ♫ ♪");
        }
    }

    public static class Piano implements Playable {
        @Override
        public void play() {
            System.out.println("Tocando el piano: ♫ ♪ ♫");
        }
    }

    // 3. Clases Animal, Dog y Cat
    public static abstract class Animal {
        public abstract void makeSound();
    }

    public static class Dog extends Animal {
        @Override
        public void makeSound() {
            System.out.println("El perro hace: Guau");
        }
    }

    public static class Cat extends Animal {
        @Override
        public void makeSound() {
            System.out.println("El gato hace: Miau");
        }
    }

    // 4. Interfaz Drawable y clases de figuras
    public interface Drawable {
        void draw();
    }

    public static class DrawableCircle implements Drawable {
        @Override
        public void draw() {
            System.out.println("Dibujando un círculo: ○");
        }
    }

    public static class DrawableSquare implements Drawable {
        @Override
        public void draw() {
            System.out.println("Dibujando un cuadrado: □");
        }
    }

    public static class DrawableTriangle implements Drawable {
        @Override
        public void draw() {
            System.out.println("Dibujando un triángulo: △");
        }
    }

    // 5. Clases Employee, FullTimeEmployee y PartTimeEmployee
    public static abstract class Employee {
        public abstract double calculateSalary();
    }

    public static class FullTimeEmployee extends Employee {
        private final double monthlySalary;

        public FullTimeEmployee(double monthlySalary) {
            this.monthlySalary = monthlySalary;
        }

        @Override
        public double calculateSalary() {
            return monthlySalary;
        }
    }

    public static class PartTimeEmployee extends Employee {
        private final int hoursWorked;
        private final double hourlyRate;

        public PartTimeEmployee(int hoursWorked, double hourlyRate) {
            this.hoursWorked = hoursWorked;
            this.hourlyRate = hourlyRate;
        }

        @Override
        public double calculateSalary() {
            return hoursWorked * hourlyRate;
        }
    }

    // 6. Interfaz Movable y clases Car y Robot
    public interface Movable {
        void move();
    }

    public static class Car implements Movable {
        @Override
        public void move() {
            System.out.println("El coche se mueve por la carretera");
        }
    }

    public static class Robot implements Movable {
        @Override
        public void move() {
            System.out.println("El robot se mueve con sus servomotores");
        }
    }

    // 7. Clases Appliance, TV y WashingMachine
    public static abstract class Appliance {
        public abstract void turnOn();
        public abstract void turnOff();
    }

    public static class TV extends Appliance {
        @Override
        public void turnOn() {
            System.out.println("Encendiendo la televisión");
        }

        @Override
        public void turnOff() {
            System.out.println("Apagando la televisión");
        }
    }

    public static class WashingMachine extends Appliance {
        @Override
        public void turnOn() {
            System.out.println("Encendiendo la lavadora");
        }

        @Override
        public void turnOff() {
            System.out.println("Apagando la lavadora");
        }
    }

    // 8. Interfaces Flyable y Swimmable, y clase Duck
    public interface Flyable {
        void fly();
    }

    public interface Swimmable {
        void swim();
    }

    public static class Duck implements Flyable, Swimmable {
        @Override
        public void fly() {
            System.out.println("El pato está volando");
        }

        @Override
        public void swim() {
            System.out.println("El pato está nadando");
        }
    }

    // 9. Clases Document, PDFDocument y WordDocument
    public static abstract class Document {
        public abstract void print();
    }

    public static class PDFDocument extends Document {
        @Override
        public void print() {
            System.out.println("Imprimiendo documento PDF...");
        }
    }

    public static class WordDocument extends Document {
        @Override
        public void print() {
            System.out.println("Imprimiendo documento de Word...");
        }
    }

    // 10. Interfaz Payable y clases Invoice y EmployeePayment
    public interface Payable {
        void pay();
    }

    public static class Invoice implements Payable {
        private final double amount;

        public Invoice(double amount) {
            this.amount = amount;
        }

        @Override
        public void pay() {
            System.out.println("Pagando factura por €" + amount);
        }
    }

    public static class EmployeePayment implements Payable {
        private final String employeeName;
        private final double salary;

        public EmployeePayment(String employeeName, double salary) {
            this.employeeName = employeeName;
            this.salary = salary;
        }

        @Override
        public void pay() {
            System.out.println("Pagando salario de €" + salary + " a " + employeeName);
        }
    }
}
