public class Classes {

    public static void main(String[] args) {
        var person = new Person("Brais", 38, "123456789A");
        person.sayHello();
    }
}
