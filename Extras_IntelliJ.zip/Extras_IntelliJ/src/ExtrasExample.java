// La clase Extras está incluida en este mismo proyecto.

public class ExtrasExample {

    public static void main(String[] args) {

        Extras.test();
        System.out.println(Extras.globalName);
    }
}
