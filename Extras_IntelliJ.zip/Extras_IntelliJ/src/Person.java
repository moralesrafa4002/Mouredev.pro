public class Person {

    private String name;
    private int age;
    private final String id;

    public Person(String name, int age, String id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    public void sayHello() {
        System.out.println("Hola, soy " + name + ", tengo " + age + " años y mi id es " + id + ".");
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getId() {
        return id;
    }
}
