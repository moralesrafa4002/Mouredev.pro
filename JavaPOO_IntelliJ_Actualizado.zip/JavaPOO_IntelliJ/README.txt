PROYECTO JAVA PARA INTELLIJ IDEA

Este proyecto contiene ejercicios básicos de Java separados en archivos independientes.

Clases incluidas:
1. HelloWorld.java
2. HelloWorldExercises.java
3. HelloWorldCorrections.java
4. VariablesAndConstants.java
5. DataTypes.java

INSTRUCCIONES PARA ABRIR EN INTELLIJ:
1. Descomprime el archivo ZIP.
2. Abre IntelliJ IDEA.
3. Selecciona File > Open.
4. Elige la carpeta JavaPOO_IntelliJ.
5. Abre cualquier archivo dentro de src.
6. Ejecuta la clase que tenga método main.

Nota:
Cada clase pública está separada en su propio archivo .java para evitar errores de compilación.
