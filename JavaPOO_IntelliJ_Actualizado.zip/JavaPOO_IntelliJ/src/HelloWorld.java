// Hola Mundo

/*
 * Hola
 * Mundo
 */

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hola, Java!");
    }
}
