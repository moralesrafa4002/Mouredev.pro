// La clase Person se encuentra en el archivo Person.java de este mismo proyecto.

public class Classes {

    public static void main(String[] args) {

        var person = new Person("Brais", 38, "123456789A");

        // person.name = "Brais"; // Error: el atributo es privado
        // person.age = 38;       // Error: el atributo es privado

        person.sayHello();

        // person.name = "Brais Moure"; // Error: debe usarse un setter si existe
        // System.out.println(person.name);
    }
}
