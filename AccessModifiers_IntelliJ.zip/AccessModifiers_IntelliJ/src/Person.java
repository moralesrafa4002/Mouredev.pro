public class Person {

    // Atributos privados: solo pueden modificarse desde esta clase.
    private String name;
    private int age;
    private final String id;

    // Constructor
    public Person(String name, int age, String id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    // Método público
    public void sayHello() {
        System.out.println("Hola, soy " + name + ", tengo " + age + " años y mi id es " + id + ".");
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getId() {
        return id;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("Edad no válida");
        }
    }
}
