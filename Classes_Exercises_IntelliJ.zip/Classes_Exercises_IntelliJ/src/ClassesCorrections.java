import java.util.ArrayList;

public class ClassesCorrections {

    public static void main(String[] args) {

        // 1. Crea una clase Book con atributos title y author. Crea un objeto y muestra sus datos.
        Book book1 = new Book();
        book1.title = "El Señor de los Anillos";
        book1.author = "J. R. R. Tolkien";
        book1.showInfo();

        // 2. Crea una clase Dog con un método bark() que imprima su sonido.
        Dog dog1 = new Dog("Krypto");
        dog1.bark();

        // 3. Añade un constructor a la clase Book que reciba title y author.
        Book book2 = new Book("1984", "George Orwell");
        book2.showInfo();

        // 4. Crea una clase Car con atributos brand y model y un método showData().
        Car car1 = new Car("DMC", "DeLorean");
        car1.showData();

        // 5. Crea una clase Student con atributo score y un método que diga si aprobó.
        Student student1 = new Student("Brais", 85);
        student1.checkPassed();

        Student student2 = new Student("Moure", 45);
        student2.checkPassed();

        // 6. Crea una clase BankAccount con atributo balance y un método deposit().
        BankAccount account1 = new BankAccount("12345", 1000.0);
        account1.showBalance();
        account1.deposit(250.0);
        account1.showBalance();

        // 7. Crea una clase Rectangle con métodos para calcular el área y el perímetro.
        Rectangle rectangle1 = new Rectangle(5.0, 3.0);
        rectangle1.showCalculations();

        // 8. Crea una clase Worker que reciba nombre y salario.
        Worker worker1 = new Worker("Brais Moure", 2500.0);
        worker1.showSalary();

        // 9. Crea varios objetos Person y guárdalos en un ArrayList.
        ArrayList<Person> people = new ArrayList<>();

        people.add(new Person("Brais Moure", 21));
        people.add(new Person("MoureDev", 38));
        people.add(new Person("Brais MoureDev", 42));

        System.out.println("Lista de personas:");
        for (Person person : people) {
            person.sayHello();
        }

        // 10. Crea una clase Product y un método que aplique un descuento sobre su precio.
        Product product1 = new Product("Teclado", 199.99);
        product1.showPrice();
        product1.applyDiscount(15.0);
        product1.showPrice();
    }
}

// 1. y 3. Clase Book
class Book {
    String title;
    String author;

    public Book() {
    }

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public void showInfo() {
        System.out.println("Libro: '" + title + "' por " + author);
    }
}

// 2. Clase Dog
class Dog {
    private String name;

    public Dog(String name) {
        this.name = name;
    }

    public void bark() {
        System.out.println(name + " hace: ¡Guau guau!");
    }

    public String getName() {
        return name;
    }
}

// 4. Clase Car
class Car {
    private String brand;
    private String model;

    public Car(String brand, String model) {
        this.brand = brand;
        this.model = model;
    }

    public void showData() {
        System.out.println("Coche: " + brand + " " + model);
    }
}

// 5. Clase Student
class Student {
    private String name;
    private double score;

    public Student(String name, double score) {
        this.name = name;
        this.score = score;
    }

    public void checkPassed() {
        if (score >= 60) {
            System.out.println(name + " ha aprobado con una nota de " + score);
        } else {
            System.out.println(name + " no ha aprobado. Nota: " + score);
        }
    }
}

// 6. Clase BankAccount
class BankAccount {
    private String accountNumber;
    private double balance;

    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Depósito realizado: €" + amount);
        } else {
            System.out.println("El monto del depósito debe ser positivo");
        }
    }

    public void showBalance() {
        System.out.println("Saldo de la cuenta " + accountNumber + ": €" + balance);
    }
}

// 7. Clase Rectangle
class Rectangle {
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public void showCalculations() {
        System.out.println("Rectángulo de " + width + " x " + height);
        System.out.println("Área: " + calculateArea());
        System.out.println("Perímetro: " + calculatePerimeter());
    }

    private double calculateArea() {
        return width * height;
    }

    private double calculatePerimeter() {
        return 2 * (width + height);
    }
}

// 8. Clase Worker
class Worker {
    private String name;
    private double salary;

    public Worker(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void showSalary() {
        System.out.println("Trabajador: " + name + ", Salario: €" + salary);
    }
}

// 9. Clase Person
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void sayHello() {
        System.out.println("Hola, soy " + name + " y tengo " + age + " años.");
    }
}

// 10. Clase Product
class Product {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public void applyDiscount(double discountPercentage) {
        if (discountPercentage >= 0 && discountPercentage <= 100) {
            double discountAmount = price * (discountPercentage / 100);
            price -= discountAmount;
            System.out.println("Descuento del " + discountPercentage + "% aplicado");
        } else {
            System.out.println("El descuento debe estar entre 0 y 100%");
        }
    }

    public void showPrice() {
        System.out.println("Producto: " + name + ", Precio: €" + String.format("%.2f", price));
    }
}
